import sys
from PyQt5 import QtGui
from PyQt5.QtWidgets import (QApplication, QMainWindow)
from Дизайн import Ui_MainWindow


class Example(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.high_nut_desc = 'highnut.png'
        self.hero_1.clicked.connect(self.information_func_1)
        self.hero_2.clicked.connect(self.information_func_2)
        self.hero_3.clicked.connect(self.information_func_3)
        self.hero_4.clicked.connect(self.information_func_4)
        self.hero_5.clicked.connect(self.information_func_5)
        self.hero_6.clicked.connect(self.information_func_6)
        self.hero_7.clicked.connect(self.information_func_7)
        self.hero_8.clicked.connect(self.information_func_8)
        self.hero_9.clicked.connect(self.information_func_9)
        self.hero_10.clicked.connect(self.information_func_10)
        self.hero_11.clicked.connect(self.information_func_11)


    def information_func_1(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Горохострел1.png'))
        self.desc.setPixmap(QtGui.QPixmap('gorohostrel.png'))

    def information_func_2(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Патсолнух.png'))
        self.desc.setPixmap(QtGui.QPixmap('sunflower.png'))

    def information_func_3(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Вишнёвые бомбы.png'))
        self.desc.setPixmap(QtGui.QPixmap('cherries.png'))

    def information_func_4(self):
        self.image_connect.setPixmap(QtGui.QPixmap('СтенаОрех.png'))
        self.desc.setPixmap(QtGui.QPixmap('nut1.png'))

    def information_func_5(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Морозный Горох.png'))
        self.desc.setPixmap(QtGui.QPixmap('chavv.png'))

    def information_func_6(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Жевун.png'))
        self.desc.setPixmap(QtGui.QPixmap('frost.png'))

    def information_func_7(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Гипногриб.png'))
        self.desc.setPixmap(QtGui.QPixmap('gypno.png'))

    def information_func_8(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Ледогриб.png'))
        self.desc.setPixmap(QtGui.QPixmap('frost2'))

    def information_func_9(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Кабачок.png'))
        self.desc.setPixmap(QtGui.QPixmap('cabbage.png'))

    def information_func_10(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Колючки.jpg'))
        self.desc.setPixmap(QtGui.QPixmap('spikes.png'))

    def information_func_11(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Высокие Орехи.jpg'))
        self.desc.setPixmap(QtGui.QPixmap('highnut.png'))

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    ex.show()
    sys.exit(app.exec_())