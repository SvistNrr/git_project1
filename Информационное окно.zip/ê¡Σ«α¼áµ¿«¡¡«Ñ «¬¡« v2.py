import sys
from PyQt5 import QtGui
from PyQt5.QtWidgets import (QApplication, QMainWindow)
from Дизайн import Ui_MainWindow


class Example(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.gorohostrel_desc = 'gorohostrel.png'
        self.podsolnuh_desc = 'podsolnuh(1).png'
        self.cherries_desc = 'cherries.png'
        self.nut_desc = 'nut1.png'
        self.chavv_desc = 'chavv.png'
        self.frost_desc = 'frost.png'
        self.gypno_desc = 'gypno.png'
        self.frost_2_desc = 'frost2'
        self.cabbage_desc = 'cabbage.png'
        self.spikes_desc = 'spikes.png'
        self.high_nut_desc = 'highnut.png'
        self.hero_1.clicked.connect(self.information_func_1)
        self.hero_2.clicked.connect(self.information_func_2)
        self.hero_3.clicked.connect(self.information_func_3)
        self.hero_4.clicked.connect(self.information_func_4)
        self.hero_5.clicked.connect(self.information_func_5)
        self.hero_6.clicked.connect(self.information_func_6)
        self.hero_7.clicked.connect(self.information_func_7)
        self.hero_8.clicked.connect(self.information_func_8)
        self.hero_9.clicked.connect(self.information_func_9)
        self.hero_10.clicked.connect(self.information_func_10)
        self.hero_11.clicked.connect(self.information_func_11)


    def information_func_1(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Горохострел1.png'))
        self.lineEdit.setPixmap(QtGui.QPixmap(self.gorohostrel.desc))

    def information_func_2(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Патсолнух.png'))
        self.lineEdit.setPixmap(QtGui.QPixmap(self.podsolnuh_desc))

    def information_func_3(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Вишнёвые бомбы.png'))
        self.lineEdit.setPixmap(QtGui.QPixmap(self.cherries_desc))

    def information_func_4(self):
        self.image_connect.setPixmap(QtGui.QPixmap('СтенаОрех.png'))
        self.lineEdit.setPixmap(QtGui.QPixmap(self.nut_desc))

    def information_func_5(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Морозный Горох.png'))
        self.lineEdit.setPixmap(QtGui.QPixmap(self.frost_desc))

    def information_func_6(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Жевун.png'))
        self.lineEdit.setPixmap(QtGui.QPixmap(self.chavv_desc))

    def information_func_7(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Гипногриб.png'))
        self.lineEdit.setPixmap(QtGui.QPixmap(self.gypno_desc))

    def information_func_8(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Ледогриб.png'))
        self.lineEdit.setPixmap(QtGui.QPixmap(self.frost2_desc))

    def information_func_9(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Кабачок.png'))
        self.lineEdit.setPixmap(QtGui.QPixmap(self.cabbage_desc))

    def information_func_10(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Колючки.jpg'))
        self.lineEdit.setPixmap(QtGui.QPixmap(self.spikes_desc))

    def information_func_11(self):
        self.image_connect.setPixmap(QtGui.QPixmap('Высокие Орехи.jpg'))
        self.lineEdit.setPixmap(QtGui.QPixmap(self.high_nut_desc))

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    ex.show()
    sys.exit(app.exec_())